package java.util;

public class IllegalFormatConversionException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public IllegalFormatConversionException(char a1, Class<?> a2) { throw new RuntimeException("skeleton method"); }
  public char getConversion() { throw new RuntimeException("skeleton method"); }
  public Class<?> getArgumentClass() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
