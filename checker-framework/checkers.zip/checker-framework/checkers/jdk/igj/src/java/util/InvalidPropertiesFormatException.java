package java.util;

public class InvalidPropertiesFormatException extends java.io.IOException {
    private static final long serialVersionUID = 0L;
  public InvalidPropertiesFormatException(Throwable a1) { throw new RuntimeException("skeleton method"); }
  public InvalidPropertiesFormatException(String a1) { throw new RuntimeException("skeleton method"); }
}
