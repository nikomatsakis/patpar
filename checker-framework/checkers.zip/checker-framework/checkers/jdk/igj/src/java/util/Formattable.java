package java.util;
import checkers.igj.quals.*;

@I
public interface Formattable{
  public abstract void formatTo(@ReadOnly Formatter a1, int a2, int a3, int a4);
}
