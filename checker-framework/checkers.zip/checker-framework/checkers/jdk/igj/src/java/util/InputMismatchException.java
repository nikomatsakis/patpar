package java.util;

public class InputMismatchException extends NoSuchElementException{
    private static final long serialVersionUID = 0L;
  public InputMismatchException() { throw new RuntimeException("skeleton method"); }
  public InputMismatchException(String a1) { throw new RuntimeException("skeleton method"); }
}
