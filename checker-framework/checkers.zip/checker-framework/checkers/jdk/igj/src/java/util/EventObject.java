package java.util;
import checkers.igj.quals.*;

@I
public class EventObject implements java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public EventObject(@I Object a1) { throw new RuntimeException("skeleton method"); }
  public @I Object getSource() @ReadOnly { throw new RuntimeException("skeleton method"); }
  public String toString() @ReadOnly { throw new RuntimeException("skeleton method"); }
}
