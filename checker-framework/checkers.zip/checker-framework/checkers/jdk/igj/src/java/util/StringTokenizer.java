package java.util;
import checkers.igj.quals.*;

@Immutable
public class StringTokenizer implements Enumeration<Object> {
  public StringTokenizer(String a1, String a2, boolean a3) @AssignsFields { throw new RuntimeException("skeleton method"); }
  public StringTokenizer(String a1, String a2) @AssignsFields { throw new RuntimeException("skeleton method"); }
  public StringTokenizer(String a1) @AssignsFields { throw new RuntimeException("skeleton method"); }
  public boolean hasMoreTokens() { throw new RuntimeException("skeleton method"); }
  public String nextToken() { throw new RuntimeException("skeleton method"); }
  public String nextToken(String a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasMoreElements() { throw new RuntimeException("skeleton method"); }
  public Object nextElement() { throw new RuntimeException("skeleton method"); }
  public int countTokens() { throw new RuntimeException("skeleton method"); }
}
