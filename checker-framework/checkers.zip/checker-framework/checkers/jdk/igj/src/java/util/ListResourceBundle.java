package java.util;
import checkers.igj.quals.*;

@I
public abstract class ListResourceBundle extends @I ResourceBundle {
  public ListResourceBundle() @AssignsFields { throw new RuntimeException("skeleton method"); }
  public final Object  handleGetObject(String a1) @ReadOnly { throw new RuntimeException("skeleton method"); }
  public Enumeration<String> getKeys() @ReadOnly { throw new RuntimeException("skeleton method"); }
}
