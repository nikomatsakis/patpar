package java.util;
import checkers.igj.quals.*;

@I
public class LinkedHashSet<E> extends @I HashSet<E> implements @I Set<E>, @I Cloneable, @I java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public LinkedHashSet(int a1, float a2) @AssignsFields { throw new RuntimeException("skeleton method"); }
  public LinkedHashSet(int a1) @AssignsFields { throw new RuntimeException("skeleton method"); }
  public LinkedHashSet() @AssignsFields { throw new RuntimeException("skeleton method"); }
  public LinkedHashSet(@ReadOnly Collection<? extends E> a1) @AssignsFields { throw new RuntimeException("skeleton method"); }
}
