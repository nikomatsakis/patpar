package java.util;
import checkers.igj.quals.*;

@Immutable
public class PropertyResourceBundle extends ResourceBundle {
  public PropertyResourceBundle(java.io.InputStream a1) @AssignsFields throws java.io.IOException { throw new RuntimeException("skeleton method"); }
  public PropertyResourceBundle(java.io.Reader a1) @AssignsFields throws java.io.IOException { throw new RuntimeException("skeleton method"); }
  public Object  handleGetObject(String a1) @AssignsFields { throw new RuntimeException("skeleton method"); }
  public Enumeration<String> getKeys() @ReadOnly { throw new RuntimeException("skeleton method"); }
}
