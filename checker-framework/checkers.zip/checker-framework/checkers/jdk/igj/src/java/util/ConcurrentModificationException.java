package java.util;

public class ConcurrentModificationException extends RuntimeException {
    private static final long serialVersionUID = 0L;
  public ConcurrentModificationException() { throw new RuntimeException("skeleton method"); }
  public ConcurrentModificationException(String a1) { throw new RuntimeException("skeleton method"); }
}
